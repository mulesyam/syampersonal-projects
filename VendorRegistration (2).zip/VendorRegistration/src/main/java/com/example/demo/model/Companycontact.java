package com.example.demo.model;


import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@Entity
@Table(name="companycontact")
public class Companycontact {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	//	@Column(name="companyname")
	@NotNull(message="provide company name")
	@Pattern(regexp = "^[a-zA-Z]*$" ,message="provide company name" )
	private String companyname;

	@NotNull(message="provide telephone")
	@Size(min=10,max=10)
	@Pattern(regexp = "^[0-9]*$" ,message="provide telephone")
	private String telephone;

	@NotNull(message="provide fax")
	private String fax;

	@NotNull(message="provide email")
	@Email
	private String email;

	@NotNull(message="provide point of contact")
	private String pcontactname;
	@Size(min=10,max=10)
	@NotNull(message="provide contact phone1")
	private String contactphone1;
	@Size(min=10,max=10)
	@NotNull(message="provide contact phone2")
	private String contactphone2;
	@Pattern(regexp = "^[a-zA-Z]*$",message="provide mailing address")
	@NotNull(message="provide mailing address")
	private String mailingaddress;
	@Pattern(regexp = "^[a-zA-Z:/.]*$",message="provide website")
	@NotNull(message="provide website")
	private String website;
    @Email
	@NotNull(message="provide contact email")
	private String contactemail;
	
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPcontactname() {
		return pcontactname;
	}
	public void setPcontactname(String pcontactname) {
		this.pcontactname = pcontactname;
	}
	public String getContactphone1() {
		return contactphone1;
	}
	public void setContactphone1(String contactphone1) {
		this.contactphone1 = contactphone1;
	}
	public String getContactphone2() {
		return contactphone2;
	}
	public void setContactphone2(String contactphone2) {
		this.contactphone2 = contactphone2;
	}
	public String getMailingaddress() {
		return mailingaddress;
	}
	public void setMailingaddress(String mailingaddress) {
		this.mailingaddress = mailingaddress;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getContactemail() {
		return contactemail;
	}
	public void setContactemail(String contactemail) {
		this.contactemail = contactemail;
	}
    public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Companycontact [companyname=" + companyname + ", telephone=" + telephone + ", fax=" + fax + ", email="
				+ email + ", pcontactname=" + pcontactname + ", contactphone1=" + contactphone1 + ", contactphone2="
				+ contactphone2 + ", mailingaddress=" + mailingaddress + ", website=" + website + ", contactemail="
				+ contactemail + "]";
	}
	

}
