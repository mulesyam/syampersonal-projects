package com.example.demo.model;

public class ViewModel {
	private String companyname;
	private String email;
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		companyname = companyname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		email = email;
	}
	public ViewModel() {
		super();
	}
	

}
