package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Certification;

@Repository
public interface CertificationRepository extends JpaRepository<Certification, Integer> {
	@Query(value="select * from certification where id=?1",nativeQuery = true)
	Certification findById(int id);
}
