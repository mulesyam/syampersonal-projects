package com.example.demo.Controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.xhtmlrenderer.layout.SharedContext;
import org.xhtmlrenderer.pdf.ITextRenderer;
import org.xhtmlrenderer.pdf.util.XHtmlMetaToPdfInfoAdapter;

import com.example.demo.Repository.AddressRepository;
import com.example.demo.Repository.CompanycontactRepository;
import com.example.demo.Repository.DateRepository;
import com.example.demo.Repository.InvoiceRepository;
import com.example.demo.Service.EmailService;
import com.example.demo.Service.InvoiceService;
import com.example.demo.Service.PdfExporter;
import com.example.demo.Service.Vendorservice;
import com.example.demo.model.Address;
import com.example.demo.model.Bankinginformation;
import com.example.demo.model.Certification;
import com.example.demo.model.Companycontact;
import com.example.demo.model.Companyoverview;
import com.example.demo.model.Email;
import com.example.demo.model.Invoice;
import com.example.demo.model.InvoiceDto;
import com.example.demo.model.ViewModel;
import com.itextpdf.html2pdf.HtmlConverter;

import com.itextpdf.styledxmlparser.jsoup.Jsoup;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.html.simpleparser.HTMLWorker;
import com.lowagie.text.pdf.PdfWriter;

import jakarta.mail.MessagingException;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class AdminController {
	@Autowired
	Vendorservice service;

	@Autowired
	InvoiceService invoservice;
	@Autowired
	CompanycontactRepository ccrepo;
	@Autowired
	InvoiceRepository invorepo;
	@Autowired
	AddressRepository adrepo;
	@Autowired
	DateRepository dtrepo;
	 @Autowired 
	  EmailService emailService;

	@GetMapping("/home1")
	public String home() {
		return "home1";
	}

	@GetMapping("/adminview")
	public String viewdata(Model model) {
		List<Companycontact> list = service.viewusers();
		model.addAttribute("list", list);
		List<String> arraylist = new ArrayList<>();
		/*
		 * for(Companycontact li:list) { String emaillist=li.getEmail();
		 * arraylist.add(emaillist); }
		 */
		return "view";
	}

	@GetMapping(value = "/view/{email}", produces = MediaType.APPLICATION_PDF_VALUE)
	public ModelAndView viewbyemail(@PathVariable String email) {
		ModelAndView mv = new ModelAndView("adminpreview");
		Companycontact cc = service.getDetails(email);
		int id = cc.getId();
		Companyoverview co = service.getcodetails(id);
		Bankinginformation bi = service.getbidetails(id);
		Certification cer = service.getcerdetails(id);
		mv.addObject("cc", cc);
		mv.addObject("co", co);
		mv.addObject("bi", bi);
		mv.addObject("cer", cer);
		return mv;
	}
	@GetMapping(value = "/pdf/{email}/{companyname}", produces = MediaType.APPLICATION_PDF_VALUE)
	public String viewbyemail1(@PathVariable String email,String companyname, Model mv,HttpServletResponse response) throws IOException {
		//ModelAndView mv = new ModelAndView("adminpreview");
		Companycontact cc = service.getDetails(email);
		int id = cc.getId();
		Companyoverview co = service.getcodetails(id);
		Bankinginformation bi = service.getbidetails(id);
		Certification cer = service.getcerdetails(id);
		mv.addAttribute("cc", cc);
		mv.addAttribute("co", co);
		mv.addAttribute("bi", bi);
		mv.addAttribute("cer", cer);
		String str=cc.getCompanyname();
		String name=str.concat(".pdf");
		OutputStream file=new FileOutputStream(new File("C:\\Users\\appadmin\\Downloads\\"+name));
		String file1="C:\\Users\\appadmin\\Downloads\\"+name;
		Cookie filepath=new Cookie("file1",file1);
		response.addCookie(filepath);
		//String outputfilename="C:\\Users\\appadmin\\Downloads\\"+name;
		//InputStreamResource resource = new InputStreamResource(new FileInputStream(outputfilename));
		//  Document document=new Document(); PdfWriter.getInstance(document, file);
		 // document.open(); HTMLWorker htmlworker=new HTMLWorker(document);
		  //htmlworker.parse(new StringReader(sample.jsp));
		 
	//	file.close();
		HtmlConverter.convertToPdf("<html>"
				+ "<head>\r\n"
				+ "        <title>Registration Form</title>\r\n"
				+ "        <link rel=\"icon\" href=\"https://media-exp1.licdn.com/dms/image/C4E0BAQGngkKkete2NQ/company-logo_200_200/0/1519879071840?e=2147483647&v=beta&t=olxeabeCGFRzSY4mnGtXOv8ZunHk-iWYhiwD5TFxgsU\">\r\n"
				+ "\r\n"
				+ "        <style type=\"text/css\">\r\n"
				+ "           \r\n"
				+ "            table,th,td {\r\n"
				+ "                border: 10px;\r\n"
				+ "              width: 100%;\r\n"
				+ "             \r\n"
				+ "              border-collapse: collapse;\r\n"
				+ "              border: 1px solid black;\r\n"
				+ "             border-collapse:collapse;\r\n"
				+ "             \r\n"
				+ "           \r\n"
				+ "            }\r\n"
				+ "            \r\n"
				+ "            .alignleft {\r\n"
				+ "	         float: left;\r\n"
				+ "             }\r\n"
				+ "               .alignright {\r\n"
				+ "	         float: right;\r\n"
				+ "              }\r\n"
				+ "              img{\r\n"
				+ "              padding: 10px;\r\n"
				+ "                float: right; \r\n"
				+ "                border-radius: 15px;\r\n"
				+ "            }\r\n"
				+ "\r\n"
				+ "            input,textarea{\r\n"
				+ "                border: 0px;\r\n"
				+ "                row-gap: 20;\r\n"
				+ "                \r\n"
				+ "            }\r\n"
				+ "\r\n"
				+ "            *{\r\n"
				+ "               \r\n"
				+ "                box-sizing: border-box;\r\n"
				+ "            }\r\n"
				+ "\r\n"
				+ "            input{\r\n"
				+ "                outline: none;\r\n"
				+ "                font-size: 14px;\r\n"
				+ "                font-weight: 400;\r\n"
				+ "                padding: 0px 0px;\r\n"
				+ "            }\r\n"
				+ "            td:nth-child(even) {background-color:  white}\r\n"
				+ "            </style>\r\n"
				+ "\r\n"
				+ "    </head>"
				+ "<body  bgcolor=\"orange\">"
				+ "<h4>COMPANY CONTACT</h4>"
				+ "<table border=\"1px\"  bgcolor=\"red\">\r\n"
				+ "           <h4>\r\n"
				+ "            <tr>\r\n"
				+ "                <td><label>COMPANY NAME</label></td>\r\n"
				+ "                <td><input type=\"text\" id=\"cn\" value="+cc.getCompanyname()+ "></td>\r\n"
				+ "                <td rowspan=\"3\"><label>MAILING ADDRESS</label></td>  \r\n"
				+ "                <td><input type=\"text\" id=\"ma\"  value="+cc.getMailingaddress()+" ></td>  \r\n"
				+ "              \r\n"
				+ "            </tr></h4>  "
				+ "            <tr>   \r\n"
				+ "                <td><label>TELEPHONE</label></td>\r\n"
				+ "                <td><input type=\"text\" id=\"tp\" value="+cc.getTelephone()+">"
				
				+ "                <td><input type=\"text\" id=\"ma\" name=\"maddress2\"  ></td>\r\n"
				+ "            </tr>\r\n"
				+ "            <tr>   \r\n"
				+ "                <td><label>FAX</label></td>\r\n"
				+ "                <td><input type=\"text\" id=\"fax\"  value="+cc.getFax()+" ></td>\r\n"
				+ "                <td><input type=\"text\" id=\"ma\" name=\"maddress3\"  ></td>\r\n"
				+ "            </tr> \r\n"
				+ "            <tr>   \r\n"
				+ "                <td><label>EMAIL</label></td>\r\n"
				+ "                <td><input type=\"email\" id=\"email\" value="+cc.getEmail()+" ></td>\r\n"
				+ "                <td><label>WEBSITE</label></td>\r\n"
				+ "                <td><input type=\"text\" id=\"web\" value="+cc.getWebsite()+" ></td>\r\n"
				+ "            </tr>\r\n"
				+ "            <tr>\r\n"
				+ "                    <td><label>POINT OF CONTECT<br> NAME AND TITLE</label></td>\r\n"
				+ "                    <td><input type=\"text\" id=\"poc\" value="+cc.getPcontactname()+"></td>\r\n"
				+ "                    <td ><label>CONTACT EMAIL</label></td>\r\n"
				+ "                    <td><input type=\"email\" id=\"cemail\" value="+cc.getContactemail()+"></td>\r\n"
				+ "            </tr>\r\n"
				+ "            <tr>\r\n"
				+ "                    <td><label>CONTACT PHONE 1</label></td>\r\n"
				+ "                    <td><input type=\"text\" id=\"cn1\" value="+cc.getContactphone1()+" >"
				+ "                    <td ><label>CONTACT PHONE 2</label></td>\r\n"
				+ "                    <td><input type=\"text\" id=\"cn2\" value="+cc.getContactphone2()+">"
				+ "            </tr>"
				+ "</table>"
				+ " <h4>COMPANY OVERVIEW</h4>\r\n"
				+ "          <table   bgcolor=\"#ebebeb\">\r\n"
				+ "            <tr>\r\n"
				+ "         \r\n"
				+ "                <td><label for=\"gds\">GENERAL DETAILS OF SERVICE/GOODS</label></td>\r\n"
				+ "                <td COLspan=\"3\"><input type=\"text\" id=\"gds\" value="+co.getDetailsofservices()+"  ></td>\r\n"
				+ "            </tr>\r\n"
				+ "            <tr>  \r\n"
				+ "                <td><label>DATE COMPANY ESTABLISHED</label></td>\r\n"
				+ "                <td><input type=\"text\" id=\"dce\" value="+co.getCompanyestablished()+"  ></td>\r\n"
				+ "                <td><label>GROSS ANNUAL SALES</label></td>\r\n"
				+ "                <td><input type=\"text\" id=\"gas\" value="+co.getGrossannualsales()+" ></td>\r\n"
				+ "            </tr>\r\n"
				+ "            <tr>   \r\n"
				+ "                <td><label>GEOGRAPHIC SERVICE AREA</label></td>\r\n"
				+ "                <td><input type=\"text\" id=\"gsa\"  value="+co.getServicearea()+"  ></td>\r\n"
				+ "                <td><label>LEGAL STRUCTOR</label></td>\r\n"
				+ "                <td><input type=\"text\" id=\"leg\" value="+co.getLegalstructure()+"   ></td>\r\n"
				+ "            </tr>\r\n"
				+ "            <tr>   \r\n"
				+ "                <td><label>BUSENESS TYPE</label></td>\r\n"
				+ "                <td><input type=\"text\" id=\"bt\" value="+co.getBusinesstype()+"  ></td>\r\n"
				+ "                <td><label>YEARS PREVIOUSLY REGISTRED</label></td>\r\n"
				+ "                <td><input type=\"text\" id=\"ypr\" value="+co.getRegisteredyears()+"  ></td>\r\n"
				+ "            </tr>\r\n"
				+ "            <tr>\r\n"
				+ "                   <td><label for=\"ins\">INSURED ?</label></td>\r\n"
				+ "                   <td><input type=\"text\" value="+co.getInsured()+">\r\n"
				+ "\r\n"
				+ "                    </select></td> \r\n"
				+ "                   \r\n"
				+ "                   <td><label for=\"bond\">BONDED ?</label></td>\r\n"
				+ "                   <td><input type=\"text\" value="+co.getBonded()+" >\r\n"
				+ "                    </select></td> \r\n"
				+ "            </tr> \r\n"
				+ "            <tr>\r\n"
				+ "                    <td><label for=\"lic\">LICENSED</label></td>\r\n"
				+ "                    <td><input type=\"text\" value="+co.getLicensed()+">\r\n"
				+ "                    <td ><label>LICENSE NUMBER</label></td>\r\n"
				+ "                    <td><input type=\"text\" id=\"lcn\" value="+co.getLicensenumber()+" ></td>\r\n"
				+ "            </tr> <tr>\r\n"
				+ "                <td><label>ADDITIONAL INFO</label></td>\r\n"
				+ "                <td colspan=\"3\"><input type=\"text\" id=\"addin\" value="+co.getAdditionalinfo()+" ></td>\r\n"
				+ "        </tr>\r\n"
				+ "    </td></table>"
				+ "<h4>BANKING INFORMATION</h4>\r\n"
				+ "          <table bgcolor=\"#ebebeb\"> \r\n"
				+ "            <tr>   \r\n"
				+ "                <td><label>BANK NAME</label></td>\r\n"
				+ "                <td><input type=\"text\" id=\"bank\" value="+bi.getBankname()+" ></td>\r\n"
				+ "                <td rowspan=\"3\"><label>BANK ADDRESS</label></td>\r\n"
				+ "                <td><input type=\"text\" id=\"badd\" value="+bi.getBankaddress()+" ></td>\r\n"
				+ "            </tr>\r\n"
				+ "            <tr>\r\n"
				+ "                    <td><label>BENEFICIARY NAME</label></td>\r\n"
				+ "                    <td><input type=\"text\" id=\"ben\" value="+bi.getBeneficiaryname()+" ></td>\r\n"
				+ "                    <td><input type=\"text\" id=\"badd\" name=\"badd2\"></td>\r\n"
				+ "                    \r\n"
				+ "            </tr> \r\n"
				+ "            <tr>\r\n"
				+ "                <td ><label>ACCOUNT NUMBER</label></td>\r\n"
				+ "                <td><input type=\"text\" id=\"accno\" value="+bi.getAccountnumber()+"></td>\r\n"
				+ "                    <td><input type=\"text\" id=\"badd\" name=\"badd3\"  size=\"40%\" readonly></td>\r\n"
				+ "        </tr> \r\n"
				+ "           \r\n"
				+ "    </table>"
				+ "<h4>  CIRTIFICATION  </h4>\r\n"
				+ "        <table bgcolor=\"#ebebeb\">\r\n"
				+ "         \r\n"
				+ "            <TR bgcolor=\"#c0c0c0\"><td colspan=\"6\" >\r\n"
				+ "                The hereby affirm that all information supplied is true and accurate to the best of my knowledge \r\n"
				+ "                and belief, and understand that this information will be considered material in the evaluation\r\n"
				+ "                 of quotations, bids, and proposals, Notice \r\n"
				+ "                must be given of any change in status impacting the information provided within ten (10) \r\n"
				+ "                days of said change.</TD></TR>\r\n"
				+ "            <tr>   \r\n"
				+ "                <td><label>PRINTED/TYPED NAME</label></td>\r\n"
				+ "                <td><input type=\"text\" id=\"ptn\" value="+cer.getTypedname()+" ></td>\r\n"
				+ "                <td ><label>TITLE</label></td>\r\n"
				+ "                <td><input type=\"text\" id=\"title\" value="+cer.getTitle()+"></td>\r\n"
				+ "            </tr>\r\n"
				+ "            <tr >   \r\n"
				+ "                <td ><label>SIGNATURE</label></td>\r\n"
				+ "                <td><input type=\"text\" id=\"sig\" value="+cer.getSignature()+" ></td>\r\n"
				+ "                <td ><label>DATE</label></td>\r\n"
				+ "                <td ><input type=\"text\" id=\"date\" value="+cer.getDate()+" ></td>\r\n"
				+ "            </tr>\r\n"
				+ "        </table>"
				+ "</body>"
				+ "</html>",file);
		return "adminpreview";
		
		}
	/*public void downloadpdf(String html) throws IOException
	{
		String sample=html;
		System.out.println(sample);
		 OutputStream file=new FileOutputStream(new File("C:\\Users\\appadmin\\Downloads\\test.pdf"));
		HtmlConverter.convertToPdf(sample, file);
		return;
		Document document=new Document();
		PdfWriter.getInstance(document, file);
		document.open();
		HTMLWorker htmlworker=new HTMLWorker(document);
		htmlworker.parse(new StringReader(html));
		document.close();
		file.close();
	}*/
	
		/*
		 * @GetMapping(value = "/pdf", produces = MediaType.APPLICATION_PDF_VALUE)
		 * public String pdfconverter() throws FileNotFoundException, IOException {
		 * 
		 * String html ="<html>" +"<table>" + "<h4>" + "<tr>" + "<td>" +
		 * "<label>COMPANY NAME</label>" + "</td>" + "<td>" +
		 * "<input type="text"  value="tecnics">" + "</input>" + "</td>" +
		 * "<td rowspan="3">" + "<label>MAILING ADDRESS</label>" + "</td>" + "<td>"
		 * +"<input type="text"   value="GIRISH"  size="40%" >" + "</td>" + "</tr>" +
		 * "</h4>" + "<tr>" + "<td><label>TELEPHONE</label></td>" + "<td>" +
		 * "<input type="text"  value='${cc.telephone}' >" + "</td>" + "<td>" +
		 * "<input type="text" id="ma" name="maddress2"  size="40%" >" + "</td>" +
		 * "</tr>" + "</table>" +"</html>";
		 * 
		 * 
		 * HtmlConverter.convertToPdf(html, new
		 * FileOutputStream("C:\\Users\\appadmin\\Downloads\\p1.pdf")); return "p1.pdf";
		 * }
		 */

		/*
		 * @GetMapping(value = "/download/{email}", produces =
		 * MediaType.APPLICATION_PDF_VALUE) public ResponseEntity<InputStreamResource>
		 * downloadpdf(@PathVariable String email,Model mv) throws IOException {
		 * Companycontact cc = service.getDetails(email); int id = cc.getId();
		 * Companyoverview co = service.getcodetails(id); Bankinginformation bi =
		 * service.getbidetails(id); Certification cer = service.getcerdetails(id);
		 * 
		 * mv.addAttribute("cc", cc); mv.addAttribute("co", co);
		 * mv.addAttribute("bi",bi); mv.addAttribute("cer",cer); File str="sample.jsp";
		 * HtmlConverter.convertToPdf(str, new File("demo-html.pdf"));
		 * InputStreamResource resource = new InputStreamResource(new
		 * FileInputStream("demo-html.pdf")); return
		 * (ResponseEntity<InputStreamResource>) ResponseEntity.ok().body(resource);
		 * 
		 * }
		 */
	/*
	 * @GetMapping(value = "/pdf/{email}", produces =
	 * MediaType.APPLICATION_PDF_VALUE) public ResponseEntity<InputStreamResource>
	 * pdfdownload(@PathVariable String email,Model mv) throws IOException {
	 * 
	 * Companycontact cc = service.getDetails(email); int id = cc.getId();
	 * Companyoverview co = service.getcodetails(id); Bankinginformation bi =
	 * service.getbidetails(id); Certification cer = service.getcerdetails(id);
	 * mv.addAttribute("cc", cc); mv.addAttribute("co", co); mv.addAttribute("bi",
	 * bi); mv.addAttribute("cer", cer); String sample="sample"; File inputHTML =
	 * new File(sample); Document document = Jsoup.parse(inputHTML, "UTF-8");
	 * document.outputSettings().syntax(Document.OutputSettings.Syntax.xml); String
	 * outputpdf="outputpdf"; try (OutputStream outputStream = new
	 * FileOutputStream(outputpdf)) { ITextRenderer renderer = new ITextRenderer();
	 * SharedContext sharedContext = renderer.getSharedContext();
	 * sharedContext.setPrint(true); sharedContext.setInteractive(false);
	 * renderer.setDocumentFromString(sample); renderer.layout();
	 * renderer.createPDF(outputStream); } InputStreamResource resource = new
	 * InputStreamResource(new FileInputStream(outputpdf)); return
	 * (ResponseEntity<InputStreamResource>) ResponseEntity.ok().body(resource); }
	 */
	/*
	 * @GetMapping("/pdf/{email}") public void exportToPDF(@PathVariable String
	 * email, HttpServletResponse response) throws DocumentException, IOException {
	 * response.setContentType("application/pdf"); DateFormat dateFormatter = new
	 * SimpleDateFormat("yyyy-MM-dd_HH:mm:ss"); String currentDateTime =
	 * dateFormatter.format(new Date());
	 * 
	 * String headerKey = "Content-Disposition"; String headerValue =
	 * "attachment; filename=users_" + currentDateTime + ".pdf";
	 * response.setHeader(headerKey, headerValue);
	 * 
	 * Companycontact listUsers = ccrepo.findByEmail(email);
	 * System.out.println(listUsers);
	 * 
	 * PdfExporter exporter = new PdfExporter(listUsers); exporter.export(response);
	 * 
	 * }
	 */

	@GetMapping("/viewemail")
	public String viewemailform() {
		return "updatebyemail";
	}

	@PostMapping("/adminupdatebyemail")
	public ModelAndView detailsbyemail(@RequestParam String email) {
		ModelAndView mv = new ModelAndView("adminupdatepreview");
		Companycontact cc = service.getDetails(email);
		int id = cc.getId();
		Companyoverview co = service.getcodetails(id);
		Bankinginformation bi = service.getbidetails(id);
		Certification cer = service.getcerdetails(id);
		mv.addObject("cc", cc);
		mv.addObject("co", co);
		mv.addObject("bi", bi);
		mv.addObject("cer", cer);
		return mv;
	}

	@RequestMapping("/deletemail")
	public String deleteemailform() {
		return "deletebyemail";
	}

	@PostMapping("deletebyemail")
	public ModelAndView deletebyemail(@RequestParam String email, HttpServletResponse response) {
		String email1 = email;
		Cookie cookie = new Cookie("email", email1);
		response.addCookie(cookie);
		ModelAndView mv = new ModelAndView("deletepreview");
		Companycontact cc = service.getDetails(email);
		int id = cc.getId();
		Companyoverview co = service.getcodetails(id);
		Bankinginformation bi = service.getbidetails(id);
		Certification cer = service.getcerdetails(id);
		mv.addObject("cc", cc);
		mv.addObject("co", co);
		mv.addObject("bi", bi);
		mv.addObject("cer", cer);
		return mv;

	}

	@PostMapping("/admindelete")
	public String delete(@CookieValue(value = "email") String email) {
		service.delete(email);
		return "adminmessage";
	}

	@PostMapping("/adminupdate")
	public String update(Companycontact cc, Companyoverview co, Bankinginformation bi, Certification cer) {
		service.updatecontact(cc, co, bi, cer);
		return "home1";
	}

	@GetMapping("/newjsp")
	public String ajax() {
		return "NewFile";
	}

	@GetMapping("/invoice")
	public String invoice() {
		return "invoice";
	}

	@GetMapping("/viewinvoices")
	public String viewinvoices(Model model) {
		List<InvoiceDto> list = invoservice.viewinvoices();
		model.addAttribute("invoices", list);
		return "viewinvoices";
	}
	@GetMapping("/viewinvoicedetails/{email}")
	public String viewinvoicedetails(Model m,@PathVariable String email)
	{
		Invoice inv=invorepo.findByEmail(email);
		Address adr=adrepo.findByEmail(email);
		com.example.demo.model.Date dt=dtrepo.findByEmail(email);
		m.addAttribute("inv", inv);
		m.addAttribute("adr", adr);
		m.addAttribute("dt", dt);
		return "invoicepreview";
	}

	@GetMapping("/dashboard")
	public String dashboard() {
		return "dashboard";
	}
	@GetMapping("/sendMail/{email}/{companyname}")
    public String sendMail(@PathVariable String email,@PathVariable String companyname) throws MessagingException
    {
		return emailService.sendMailWithAttachment(email,companyname);
        
    }

}
