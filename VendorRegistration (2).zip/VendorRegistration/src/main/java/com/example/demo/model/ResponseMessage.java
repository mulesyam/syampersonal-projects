package com.example.demo.model;

public class ResponseMessage {
	String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public ResponseMessage() {
		super();
	}

	public ResponseMessage(String message) {
		super();
		this.message = message;
	}
	

}
