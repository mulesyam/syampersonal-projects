package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.Repository.BankinginformationRepository;
import com.example.demo.Repository.CertificationRepository;
import com.example.demo.Repository.CompanycontactRepository;
import com.example.demo.Repository.CompanyoverviewRepository;
import com.example.demo.Repository.LoginRepository;
import com.example.demo.Repository.RegisterRepository;
import com.example.demo.model.Bankinginformation;
import com.example.demo.model.Certification;
import com.example.demo.model.Companycontact;
import com.example.demo.model.Companyoverview;
import com.example.demo.model.Login;
import com.example.demo.model.Register;
import com.example.demo.model.ViewModel;

import jakarta.persistence.EntityManager;
import jakarta.validation.Valid;

@Service
public class Vendorservice {
	@Autowired
	CompanycontactRepository ccrepo;
	@Autowired
	CompanyoverviewRepository corepo;
	@Autowired
	BankinginformationRepository birepo;
	@Autowired
	CertificationRepository crepo;
	@Autowired
	RegisterRepository rrepo;
	@Autowired
	LoginRepository lrepo;

	public void register( Register reg)
	{
		rrepo.save(reg);
		Login log=new Login();
		log.setEmail(reg.getEmail());
		log.setPassword(reg.getPassword());
		log.setGroupid("user");
		lrepo.save(log);
		
	}
	public Login login(String email,String password)
	{
		Login login=lrepo.findByEmailAndPassword(email,password);
		return login;
	}
	
	public Companycontact insertcontact(@Valid @RequestBody Companycontact cc)
	{
		return ccrepo.save(cc);
	}
	public Companyoverview insertoverview(@Valid @RequestBody Companyoverview co)
	{
		return corepo.save(co);
	}
	public Bankinginformation insertbanking(@Valid Bankinginformation bi)
	{
		return birepo.save(bi);
	}
	public Certification insertcertification(@Valid Certification cer)
	{
		return crepo.save(cer);
	}
	public Companycontact getDetails(String email)
	{
		Companycontact cc=ccrepo.findByEmail(email);
		 return cc;
	}
    public void updatecontact(Companycontact cc,Companyoverview co,Bankinginformation bi,Certification cer)
    {
    	String email=cc.getEmail();
    	Companycontact ccupdated=ccrepo.findByEmail(email);
    	int id=ccupdated.getId();
    	ccupdated.setEmail(cc.getEmail());
    	ccupdated.setContactemail(cc.getContactemail());
    	ccupdated.setContactphone1(cc.getContactphone1());
    	ccupdated.setContactphone2(cc.getContactphone2());
    	ccupdated.setFax(cc.getFax());
    	ccupdated.setMailingaddress(cc.getMailingaddress());
    	ccupdated.setPcontactname(cc.getPcontactname());
    	ccupdated.setTelephone(cc.getTelephone());
    	ccupdated.setWebsite(cc.getWebsite());
    	ccupdated.setContactemail(cc.getContactemail());
    	ccrepo.save(ccupdated);
    	Companyoverview coupdated=corepo.getById(id);
    	coupdated.setAdditionalinfo(co.getAdditionalinfo());
    	coupdated.setBonded(co.getBonded());
    	coupdated.setBusinesstype(co.getBusinesstype());
    	coupdated.setCompanyestablished(co.getCompanyestablished());
    	coupdated.setDetailsofservices(co.getDetailsofservices());
    	coupdated.setGrossannualsales(co.getGrossannualsales());
    	coupdated.setInsured(co.getInsured());
    	coupdated.setLegalstructure(co.getLegalstructure());
    	coupdated.setLicensed(co.getLicensed());
    	coupdated.setRegisteredyears(co.getRegisteredyears());
    	coupdated.setServicearea(co.getServicearea());
    	corepo.save(coupdated);
    	Bankinginformation biupdated=birepo.getById(id);
    	biupdated.setBankname(bi.getBankname());
    	biupdated.setAccountnumber(bi.getAccountnumber());
    	biupdated.setBankaddress(bi.getBankaddress());
    	biupdated.setBeneficiaryname(bi.getBeneficiaryname());
    	birepo.save(biupdated);
    	Certification cerupdated=crepo.getById(id);
    	cerupdated.setTypedname(cer.getTypedname());
    	cerupdated.setTitle(cer.getTitle());
    	cerupdated.setSignature(cer.getSignature());
    	cerupdated.setDate(cer.getDate());
    	crepo.save(cerupdated);
    	
    }
    public String delete(String email)
    {
    	Companycontact ccupdated=ccrepo.findByEmail(email);
    	if(ccupdated==null)
    	{
    		return "erroremail";
    	}
    	else {
    	int id=ccupdated.getId();
    	ccrepo.deleteById(id);
    	corepo.deleteById(id);
    	birepo.deleteById(id);
    	crepo.deleteById(id);
    	return "message";
    	}
    }
    public List<Companycontact> viewusers()
    {
    	List<Companycontact> li=ccrepo.findusers();
    	return li;
    }
	public Companyoverview getcodetails(int id) {
		Companyoverview co=corepo.findById(id);
		return co;
	}
	public Bankinginformation getbidetails(int id) {
		Bankinginformation bi=birepo.findById(id);
		return bi;
	}
	public Certification getcerdetails(int id) {
		Certification cer=crepo.findById(id);
		return cer;
	}
}
