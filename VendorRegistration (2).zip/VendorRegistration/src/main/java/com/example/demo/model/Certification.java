package com.example.demo.model;

import java.sql.Date;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
public class Certification {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@NotNull(message="provide typed name")
	@Pattern(regexp="^[a-zA-Z]+$")
	private String typedname;
	@NotNull(message="provide title")
	@Pattern(regexp="^[a-zA-Z]+$")
	private String title;
	@NotNull(message="provide signature")
	@Pattern(regexp="^[a-zA-Z]+$")
	private String signature;
	
	@NotNull(message = "Please provide a date.")
	private Date date;
	public Certification() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTypedname() {
		return typedname;
	}
	public void setTypedname(String typedname) {
		this.typedname = typedname;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSignature() {
		return signature;
	}
	public void setSignature(String signature) {
		this.signature = signature;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	

}
