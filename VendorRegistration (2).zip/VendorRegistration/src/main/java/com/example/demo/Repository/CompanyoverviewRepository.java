package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Companyoverview;


@Repository
public interface CompanyoverviewRepository extends JpaRepository<Companyoverview, Integer>{

	@Query(value="select * from companyoverview where id=?1",nativeQuery = true)
	Companyoverview findById(int id);
}
