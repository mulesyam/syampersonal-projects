package com.example.demo.model;


import jakarta.persistence.ColumnResult;
import jakarta.persistence.ConstructorResult;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.NamedNativeQuery;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.SqlResultSetMapping;
import jakarta.persistence.Table;
import jakarta.websocket.Encoder.Text;

@NamedNativeQuery(name = "Invoice.findinvoices",
query = "select i.email as email,i.vendorname as vendorname,i.invoiceno as invoiceno,i.monthofservices as monthofservices,i.camountdue as camountdue,i.totaldue as totaldue,a.city as city,a.state as state,a.pincode as pincode,d.month as month,d.day as day,d.year as year,f.file as file from invoice i inner join address a on i.email=a.email join date d on d.email=i.email join fileupload f on i.email=f.email",
resultSetMapping = "Mapping.InvoiceDto")
@SqlResultSetMapping(name = "Mapping.InvoiceDto",
   classes = @ConstructorResult(targetClass = InvoiceDto.class,
                                                           columns = {@ColumnResult(name="email"),
                                                        		   @ColumnResult(name="vendorname"),
                                                        		   @ColumnResult(name="invoiceno"),
                                                        		   @ColumnResult(name="monthofservices"),
                                                        		   @ColumnResult(name="camountdue"),
                                                        		   @ColumnResult(name="totaldue"),
                                                        		   @ColumnResult(name="city"),
                                                        		   @ColumnResult(name="state"),
                                                        		   @ColumnResult(name="pincode"),
                                                        		   @ColumnResult(name="month"),
                                                        		   @ColumnResult(name="day"),
                                                        		   @ColumnResult(name="year"),
                                                        		   @ColumnResult(name="file")}))

@Entity
@Table(name="invoice")
public class Invoice {
	private String vendorname;
	@Id
	private String email;
	private String invoiceno;
	private String monthofservices;
	private String camountdue;
	private String extrawork;
	private String explanation;
	private String amountdue;
	private String totaldue;
	private String comments;
	public String getVendorname() {
		return vendorname;
	}
	public void setVendorname(String vendorname) {
		this.vendorname = vendorname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	/*
	 * public Address getAddress() { return address; } public void
	 * setAddress(Address address) { this.address = address; }
	 */
	 
	public String getInvoiceno() {
		return invoiceno;
	}
	public void setInvoiceno(String invoiceno) {
		this.invoiceno = invoiceno;
	}
	public String getMonthofservices() {
		return monthofservices;
	}
	public void setMonthofservices(String monthofservices) {
		this.monthofservices = monthofservices;
	}

	
	/*
	 * public Date getDate() { return date; } public void setDate(Date date) {
	 * this.date = date; }
	 */
	 
	public String getCamountdue() {
		return camountdue;
	}
	public void setCamountdue(String camountdue) {
		this.camountdue = camountdue;
	}
	public String getExtrawork() {
		return extrawork;
	}
	public void setExtrawork(String extrawork) {
		this.extrawork = extrawork;
	}
	public String getExplanation() {
		return explanation;
	}
	public void setExplanation(String explanation) {
		this.explanation = explanation;
	}
	public String getAmountdue() {
		return amountdue;
	}
	public void setAmountdue(String amountdue) {
		this.amountdue = amountdue;
	}
	public String getTotaldue() {
		return totaldue;
	}
	public void setTotaldue(String totaldue) {
		this.totaldue = totaldue;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	

}
