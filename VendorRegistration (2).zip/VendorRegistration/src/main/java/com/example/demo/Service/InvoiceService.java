package com.example.demo.Service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.Repository.AddressRepository;
import com.example.demo.Repository.DateRepository;
import com.example.demo.Repository.FileuploadRepository;
import com.example.demo.Repository.InvoiceRepository;
import com.example.demo.model.Address;
import com.example.demo.model.Date;
import com.example.demo.model.Fileupload;
import com.example.demo.model.Invoice;
import com.example.demo.model.InvoiceDto;

@Service
 public class InvoiceService {
	
	@Autowired
	InvoiceRepository invorepo;
	@Autowired
	AddressRepository adrepo;
	@Autowired
	DateRepository dtrepo;
	@Autowired
	FileuploadRepository filerepo;
	
	
	public void insertinvoice(Invoice invoice)
	{
		invorepo.save(invoice);
		
	}
	
	public void insertDate(Date date,String email)
	{
		date.setEmail(email);
		dtrepo.save(date);
	}
	public void insertAddress(Address address,String email)
	{
		address.setEmail(email);
		adrepo.save(address);
	}
   
	public void uploadfile(MultipartFile file,String email) throws IllegalStateException, IOException
	{
		file.transferTo(new File("C:\\Users\\appadmin\\Documents\\fileupload\\" +file.getOriginalFilename()));
		String filename=file.getOriginalFilename();
		Path pathToImage=Paths.get("C:\\Users\\appadmin\\Documents\\fileupload\\" +filename);
		byte[] imageBytes = Files.readAllBytes(pathToImage);
		String base64EncodedImageBytes = Base64.getEncoder().encodeToString(imageBytes);
		 //System.out.println(base64EncodedImageBytes);
		 Fileupload f=new Fileupload();
		 f.setEmail(email);
		 f.setFile(base64EncodedImageBytes);
		 filerepo.save(f);
		 
	}
	public List<InvoiceDto> viewinvoices()
    {
    	List<InvoiceDto> li=invorepo.findinvoices();
    	return li;
    }
	
}
  
