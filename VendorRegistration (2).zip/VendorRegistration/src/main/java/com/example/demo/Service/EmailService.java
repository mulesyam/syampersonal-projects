package com.example.demo.Service;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.demo.model.Email;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;


@Service
public class EmailService {
	
	 @Autowired 
	 private JavaMailSender javaMailSender;
	 
	 @Value("${spring.mail.username}") private String sender;
	 
	public String sendemail()
	{
		 SimpleMailMessage mailMessage
         = new SimpleMailMessage();
     
     // Setting up necessary details
     mailMessage.setFrom(sender);
     mailMessage.setTo("swetharuth655@gmail.com");
     mailMessage.setSubject("Hi swetha");
     mailMessage.setText("Please take care of your health");
     javaMailSender.send(mailMessage);
     String status="mail send successfully";
     return status;
     
	}
	
	 public String
	    sendMailWithAttachment(String email,String companyname) throws MessagingException
	    {
	        MimeMessage mimeMessage
	            = javaMailSender.createMimeMessage();
	        MimeMessageHelper mimeMessageHelper;
	 
	 

	            mimeMessageHelper
	                = new MimeMessageHelper(mimeMessage, true);
	            mimeMessageHelper.setFrom(sender);
	            mimeMessageHelper.setTo(email);
	            mimeMessageHelper.setSubject("Hi");
	            mimeMessageHelper.setText("Hi,\n I am attaching your vendor form here  \n\n Thanks & Regards \n Girish");
	            String name=companyname.concat(".pdf");
	            String filepath="C:/Users/appadmin/Downloads/"+name;
	            
	            FileSystemResource file
	                = new FileSystemResource(
	                    new File(filepath));
	 
	            mimeMessageHelper.addAttachment(
	                file.getFilename(), file);
	 
	            javaMailSender.send(mimeMessage);
	            return "home1";
	    }
}
