package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

//import com.example.demo.Service.InvoiceService;
import com.example.demo.Service.Vendorservice;
import com.example.demo.model.Bankinginformation;
import com.example.demo.model.Certification;
import com.example.demo.model.Companycontact;
import com.example.demo.model.Companyoverview;
import com.example.demo.model.Login;
import com.example.demo.model.Register;
import com.example.demo.model.ResponseMessage;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class VendorController {
	
	@Autowired
	Vendorservice service;
	/*
	 * @Autowired InvoiceService invoiceservice;
	 */
	
	@GetMapping("/main")
	public String getmain()
	{
		return "Main";
	}
	@GetMapping("/register")
	public String getregister()
	{
		return "register";
	}
	@PostMapping("/insertregister")
	public String insertregister(Register reg)
	{
		service.register(reg);
		return "login";
	}
	@GetMapping("/log")
	public String login()
	{
		return "login";
	}
	@PostMapping("/login")
	public String login(@RequestParam String email,@RequestParam String password,HttpServletRequest request,HttpServletResponse response)
	{
		Login user=service.login(email, password);
		String groupid=user.getGroupid();
	    request.setAttribute("user", user);
	    String email1=user.getEmail();
	    Cookie cookie=new Cookie("email",email1);
	    response.addCookie(cookie);
	    Companycontact cc=service.getDetails(email1);
	    request.setAttribute("details", cc);
		if(user==null)
		{
			return "error";
		}
		return "home";
	}
	
	
	@GetMapping("/userhome")
	public String gethome()
	{
		return "userhome";
	}
	@GetMapping("/form")
	public String getform()
	{
		return "form1";
	}
	@PostMapping("/insert")
	public ModelAndView insert(Companycontact cc,Companyoverview co, Bankinginformation bi,Certification cer )
	{
		ModelAndView mv=new ModelAndView("userhome");
		Companycontact cc1=service.insertcontact(cc);
		Companyoverview co1=service.insertoverview(co);
		Bankinginformation bi1=service.insertbanking(bi);
		Certification cer1=service.insertcertification(cer);
		mv.addObject("cc",cc1);
		mv.addObject("co",co1);
		mv.addObject("bi",bi1);
		mv.addObject("cer",cer1);
		return mv;
	}
	@RequestMapping("/retrieve")
	public String retrieve()
	{
		return "retrieve";
	}
	@GetMapping("/view")
	public ModelAndView getuserview(@CookieValue(value="email") String email) {
		ModelAndView mv=new ModelAndView("preview2");
		Companycontact cc=service.getDetails(email);
		int id=cc.getId();
		Companyoverview co=service.getcodetails(id);
		Bankinginformation bi=service.getbidetails(id);
		Certification cer=service.getcerdetails(id);
		mv.addObject("cc", cc);
		mv.addObject("co", co);
		mv.addObject("bi",bi);
		mv.addObject("cer",cer);
		return mv;
	}
	@GetMapping("/forupdate")
	public ModelAndView forupdate(@CookieValue(value="email") String email) {
		ModelAndView mv=new ModelAndView("preview");
		Companycontact cc=service.getDetails(email);
		int id=cc.getId();
		Companyoverview co=service.getcodetails(id);
		Bankinginformation bi=service.getbidetails(id);
		Certification cer=service.getcerdetails(id);
		mv.addObject("cc", cc);
		mv.addObject("co", co);
		mv.addObject("bi",bi);
		mv.addObject("cer",cer);
		return mv;
	}
	@PostMapping("/update")
	public String update(Companycontact cc,Companyoverview co, Bankinginformation bi,Certification cer)
	{
		service.updatecontact(cc, co, bi, cer);
		return "preview";
	}
	@PostMapping("/delete")
	public String delete(@RequestParam("email") String email)
	{
		return service.delete(email);
	}
	@GetMapping("/logout")
	public String logout()
	{
		return "Main";
	}
	@GetMapping("/invoiceupload")
	public String inupload()
	{
		return "invoice";
	}
	

}
