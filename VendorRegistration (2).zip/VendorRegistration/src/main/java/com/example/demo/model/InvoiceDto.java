package com.example.demo.model;

public class InvoiceDto {
	
	private String email;
	private String vendorname;
	private String invoiceno;
	private String monthofservices;
	private String camountdue;
	private String totaldue;
	private String city;
	private String state;
	private String pincode;
	private String month;
	private int day;
	private int year;
	private String file;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getVendorname() {
		return vendorname;
	}
	public void setVendorname(String vendorname) {
		this.vendorname = vendorname;
	}
	public String getInvoiceno() {
		return invoiceno;
	}
	public void setInvoiceno(String invoiceno) {
		this.invoiceno = invoiceno;
	}
	public String getMonthofservices() {
		return monthofservices;
	}
	public void setMonthofservices(String monthofservices) {
		this.monthofservices = monthofservices;
	}
	public String getCamountdue() {
		return camountdue;
	}
	public void setCamountdue(String camountdue) {
		this.camountdue = camountdue;
	}
	public String getTotaldue() {
		return totaldue;
	}
	public void setTotaldue(String totaldue) {
		this.totaldue = totaldue;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}

	
	  public String getFile() { return file; } public void setFile(String file) {
	  this.file = file; }
	 	public InvoiceDto() {
		super();
	}
	

}
