package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Fileupload;

@Repository
public interface FileuploadRepository extends JpaRepository<Fileupload, String>{

	@Query(value="select * from fileupload where email=?1",nativeQuery = true)
	Fileupload fileupload(String email);
}
