package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Bankinginformation;


@Repository
public interface BankinginformationRepository extends JpaRepository<Bankinginformation,Integer> {

	@Query(value="select * from bankinginformation where id=?1",nativeQuery = true)
	Bankinginformation findById(int id);
}
