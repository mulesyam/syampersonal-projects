package com.example.demo.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Companycontact;
import com.example.demo.model.ViewModel;


@Repository
public interface CompanycontactRepository extends JpaRepository<Companycontact, Integer> {

	 @Query(value="select * from companycontact",nativeQuery = true)
	 List<Companycontact> findusers();
     public Companycontact findByEmail(String email);
}
