package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Login;
import com.example.demo.model.Register;

@Repository
public interface RegisterRepository extends JpaRepository<Register, String> {

	

//	@Query(value="select * from register where email=?1 and password=?2",nativeQuery =true)
//	public Register findByEmailAndPassword(String email, String password);

}
