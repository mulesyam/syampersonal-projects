package com.example.demo.model;

import java.sql.Date;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotEmpty;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@Entity
@Table(name="companyoverview")
public class Companyoverview {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@NotNull
	private int licensenumber;

	@NotNull(message="provide company name")
	@Pattern(regexp="^[a-zA-Z]+$")
	private String detailsofservices;

	
	@NotNull(message = "Please provide a date")
	private Date companyestablished;

	@NotNull(message="provide Gross Annual Sales")
	@Pattern(regexp="^[a-zA-Z0-9]+$")
	private String grossannualsales;

	@NotNull(message="provide Service Area")
	@Pattern(regexp="^[a-zA-Z]+$")
	private String servicearea;

	@NotNull(message="provide business type")
	@Pattern(regexp="^[a-zA-Z]+$")
	private String businesstype;

	@NotNull(message="provide insuredor not")
	@Pattern(regexp="^[a-zA-Z]+$")
	private String insured;

	@NotNull(message="provide licensed or not")
	@Pattern(regexp="^[a-zA-Z]+$")
	private String licensed;

	@NotNull(message="provide legal structure")
	@Pattern(regexp="^[a-zA-Z]+$")
	private String legalstructure;

	@NotNull(message="provide registered years")
	@Pattern(regexp="^[0-9]+$")
	private int registeredyears;

	@NotNull(message="provide bonded or not")
	@Pattern(regexp="^[a-zA-Z]+$")
	private String bonded;
	@NotNull(message="provide company name")
	@Pattern(regexp="^[a-zA-Z]+$")
	private String additionalinfo;
	public int getLicensenumber() {
		return licensenumber;
	}
	public void setLicensenumber(int licensenumber) {
		this.licensenumber = licensenumber;
	}
	public String getDetailsofservices() {
		return detailsofservices;
	}
	public void setDetailsofservices(String detailsofservices) {
		this.detailsofservices = detailsofservices;
	}
	public Date getCompanyestablished() {
		return companyestablished;
	}
	public void setCompanyestablished(Date companyestablished) {
		this.companyestablished = companyestablished;
	}
	public String getGrossannualsales() {
		return grossannualsales;
	}
	public void setGrossannualsales(String grossannualsales) {
		this.grossannualsales = grossannualsales;
	}
	public String getServicearea() {
		return servicearea;
	}
	public void setServicearea(String servicearea) {
		this.servicearea = servicearea;
	}
	public String getBusinesstype() {
		return businesstype;
	}
	public void setBusinesstype(String businesstype) {
		this.businesstype = businesstype;
	}
	public String getInsured() {
		return insured;
	}
	public void setInsured(String insured) {
		this.insured = insured;
	}
	public String getLicensed() {
		return licensed;
	}
	public void setLicensed(String licensed) {
		this.licensed = licensed;
	}
	public String getLegalstructure() {
		return legalstructure;
	}
	public void setLegalstructure(String legalstructure) {
		this.legalstructure = legalstructure;
	}
	public int getRegisteredyears() {
		return registeredyears;
	}
	public void setRegisteredyears(int registeredyears) {
		this.registeredyears = registeredyears;
	}
	public String getBonded() {
		return bonded;
	}
	public void setBonded(String bonded) {
		this.bonded = bonded;
	}
	public String getAdditionalinfo() {
		return additionalinfo;
	}
	public void setAdditionalinfo(String additionalinfo) {
		this.additionalinfo = additionalinfo;
	}
	@Override
	public String toString() {
		return "Companyoverview [licensenumber=" + licensenumber + ", detailsofservices=" + detailsofservices
				+ ", companyestablished=" + companyestablished + ", grossannualsales=" + grossannualsales
				+ ", servicearea=" + servicearea + ", businesstype=" + businesstype + ", insured=" + insured
				+ ", licensed=" + licensed + ", legalstructure=" + legalstructure + ", registeredyears="
				+ registeredyears + ", bonded=" + bonded + ", additionalinfo=" + additionalinfo + "]";
	}
	
	

}
