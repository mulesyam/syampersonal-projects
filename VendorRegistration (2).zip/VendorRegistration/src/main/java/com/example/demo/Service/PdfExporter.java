package com.example.demo.Service;
import java.awt.Color;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.model.Companycontact;
import com.lowagie.text.*;
import com.lowagie.text.pdf.*;

import jakarta.servlet.http.HttpServletResponse;
 
 
public class PdfExporter {
	@Autowired
    private Companycontact cc;
     
    public PdfExporter(Companycontact cc) {
		super();
		this.cc = cc;
	}

	
 
    private void writeTableHeader(PdfPTable table) {
        PdfPCell cell = new PdfPCell();
        cell.setBackgroundColor(Color.BLUE);
        cell.setPadding(5);
         
        Font font = FontFactory.getFont(FontFactory.HELVETICA);
        font.setColor(Color.WHITE);
         
        cell.setPhrase(new Phrase("Company name", font));
         
        table.addCell(cell);
         
        cell.setPhrase(new Phrase("Contact Email", font));
        table.addCell(cell);
         
        cell.setPhrase(new Phrase("Contact Phone", font));
        table.addCell(cell);
         
        cell.setPhrase(new Phrase("Email", font));
        table.addCell(cell);
         
        cell.setPhrase(new Phrase("Telephone", font));
        table.addCell(cell);
        
		/*
		 * cell.setPhrase(new Phrase("MailingAddress", font)); table.addCell(cell);
		 * 
		 * cell.setPhrase(new Phrase("fax", font)); table.addCell(cell);
		 * 
		 * cell.setPhrase(new Phrase("Point of contact", font)); table.addCell(cell);
		 * 
		 * cell.setPhrase(new Phrase("website", font)); table.addCell(cell);
		 */    }
     
    private void writeTableData(PdfPTable table) 
     {
            table.addCell(cc.getCompanyname());
            table.addCell(cc.getContactemail());
            table.addCell(cc.getContactphone1());
            table.addCell(cc.getEmail());
            table.addCell(cc.getTelephone());
			
			 table.addCell(cc.getMailingaddress()); 
			 table.addCell(cc.getFax());
			 table.addCell(cc.getPcontactname());
			 table.addCell(cc.getWebsite());
			 
    }
     
    public void export(HttpServletResponse response) throws DocumentException, IOException {
        Document document = new Document(PageSize.A4);
        PdfWriter.getInstance(document, response.getOutputStream());
         
        document.open();
        Font font = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
        font.setSize(18);
        font.setColor(Color.BLUE);
         
        Paragraph p = new Paragraph("Company Contact", font);
        p.setAlignment(Paragraph.ALIGN_CENTER);
         
        document.add(p);
         
        PdfPTable table = new PdfPTable(9);
        table.setWidthPercentage(100f);
        table.setWidths(new float[] {1.5f, 1.5f, 2.0f, 2.0f, 1.5f,1.5f,1.5f,1.5f,1.5f});
        table.setSpacingBefore(10);
         
        writeTableHeader(table);
        writeTableData(table);
         
        document.add(table);
         
        document.close();
         
    }
}

